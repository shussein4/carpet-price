/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carpetprice;


import java.io.PrintStream;
import java.util.Scanner;
public class CarpetPrice {
    public static void main(String[] args) {
       double length = 0,width = 0;
       RoomDimension dimensions;
       RoomCarpet carpet;
       final double COSTPERSQRFT = 8;
       
   Scanner keyboard;
        keyboard = new Scanner(System.in);
   System.out.println("Please enter the dimensions of the"
           + " room to know the price");
   System.out.println("Enter the length:");
    length =keyboard.nextDouble();
          System.out.println("Enter the width:");
          width =keyboard.nextDouble();
          double carpetCost = keyboard.nextDouble();
          dimensions=new RoomDimension(length,width);
           carpet=new RoomCarpet(dimensions,COSTPERSQRFT);
        System.out.println(carpet);
}

            

    }
    

